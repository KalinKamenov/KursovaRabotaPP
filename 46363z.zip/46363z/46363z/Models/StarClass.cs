﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Kursova_Rabota_PP.Models
{
    public enum StarClass
    {
        O, B, A, F, G, K, M
    }
}
